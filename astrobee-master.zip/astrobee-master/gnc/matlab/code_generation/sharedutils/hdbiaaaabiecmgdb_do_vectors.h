//
// File: hdbiaaaabiecmgdb_do_vectors.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:34:45 2017
//
#ifndef SHARE_hdbiaaaabiecmgdb_do_vectors
#define SHARE_hdbiaaaabiecmgdb_do_vectors
#include "rtwtypes.h"

extern void hdbiaaaabiecmgdb_do_vectors(const real32_T a[50], const real32_T
  b_data[], const int32_T b_sizes, real32_T c_data[], int32_T *c_sizes, int32_T
  ia_data[], int32_T *ia_sizes, int32_T ib_data[], int32_T *ib_sizes);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
