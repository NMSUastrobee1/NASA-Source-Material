//
// File: hlnglfcjaiecmohl_eulers_to_quat.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1139
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Thu Aug 17 13:31:41 2017
//
#ifndef SHARE_hlnglfcjaiecmohl_eulers_to_quat
#define SHARE_hlnglfcjaiecmohl_eulers_to_quat
#include "rtwtypes.h"

extern void hlnglfcjaiecmohl_eulers_to_quat(real32_T r1, real32_T r2, real32_T
  r3, real32_T quat[4]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
