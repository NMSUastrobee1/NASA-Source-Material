//
// File: fkfcbaiengdjgdje_quaternion_to_rotation.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:33:06 2017
//
#ifndef SHARE_fkfcbaiengdjgdje_quaternion_to_rotation
#define SHARE_fkfcbaiengdjgdje_quaternion_to_rotation
#include "rtwtypes.h"

extern void fkfcbaiengdjgdje_quaternion_to_rotation(const real32_T q[4],
  real32_T R[9]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
