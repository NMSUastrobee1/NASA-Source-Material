//
// File: djmgjecbcbiengln_power.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:33:06 2017
//
#ifndef SHARE_djmgjecbcbiengln_power
#define SHARE_djmgjecbcbiengln_power
#include "rtwtypes.h"

extern void djmgjecbcbiengln_power(const real32_T a_data[], const int32_T
  a_sizes, real32_T y_data[], int32_T *y_sizes);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
