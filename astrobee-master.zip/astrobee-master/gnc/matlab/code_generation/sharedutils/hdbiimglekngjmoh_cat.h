//
// File: hdbiimglekngjmoh_cat.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1139
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Wed May 17 14:43:55 2017
//
#ifndef SHARE_hdbiimglekngjmoh_cat
#define SHARE_hdbiimglekngjmoh_cat
#include "rtwtypes.h"

extern void hdbiimglekngjmoh_cat(const uint8_T varargin_2_data[], const int32_T
  varargin_2_sizes[2], const uint8_T varargin_3_data[], const int32_T
  varargin_3_sizes[2], uint8_T y_data[], int32_T y_sizes[2]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
