//
// File: cjmgkfkfphdjaaai_xscal.h
//
// Code generated for Simulink model 'fam_force_allocation_module'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:34:01 2017
//
#ifndef SHARE_cjmgkfkfphdjaaai_xscal
#define SHARE_cjmgkfkfphdjaaai_xscal
#include "rtwtypes.h"

extern void cjmgkfkfphdjaaai_xscal(real32_T a, real32_T x[36], int32_T ix0);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
