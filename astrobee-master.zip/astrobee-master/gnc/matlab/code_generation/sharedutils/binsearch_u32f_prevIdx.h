//
// File: binsearch_u32f_prevIdx.h
//
// Code generated for Simulink model 'fam_force_allocation_module'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:34:01 2017
//
#ifndef SHARE_binsearch_u32f_prevIdx
#define SHARE_binsearch_u32f_prevIdx
#include "rtwtypes.h"

extern uint32_T binsearch_u32f_prevIdx(real32_T u, const real32_T bp[], uint32_T
  startIndex, uint32_T maxIndex);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
