//
// File: glfkdbaibaaakfcb_xscal.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:33:06 2017
//
#ifndef SHARE_glfkdbaibaaakfcb_xscal
#define SHARE_glfkdbaibaaakfcb_xscal
#include "rtwtypes.h"

extern void glfkdbaibaaakfcb_xscal(real32_T a, real32_T x[16], int32_T ix0);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
