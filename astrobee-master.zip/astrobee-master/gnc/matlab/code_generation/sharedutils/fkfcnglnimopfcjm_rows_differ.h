//
// File: fkfcnglnimopfcjm_rows_differ.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:14:10 2017
//
#ifndef SHARE_fkfcnglnimopfcjm_rows_differ
#define SHARE_fkfcnglnimopfcjm_rows_differ
#include "rtwtypes.h"

extern boolean_T fkfcnglnimopfcjm_rows_differ(const real32_T b_data[], const
  int32_T b_sizes[2], int32_T k0, int32_T k);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
