//
// File: baimfcjeeknonglf_xzlarf.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:13:05 2017
//
#ifndef SHARE_baimfcjeeknonglf_xzlarf
#define SHARE_baimfcjeeknonglf_xzlarf
#include "rtwtypes.h"

extern void baimfcjeeknonglf_xzlarf(int32_T m, int32_T n, int32_T iv0, real32_T
  tau, real32_T C_data[], int32_T ic0, int32_T ldc, real32_T work[6]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
