//
// File: djecfknojekfgdba_mldivide.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:33:06 2017
//
#ifndef SHARE_djecfknojekfgdba_mldivide
#define SHARE_djecfknojekfgdba_mldivide
#include "rtwtypes.h"

extern void djecfknojekfgdba_mldivide(const real32_T A[225], real32_T B[225]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
