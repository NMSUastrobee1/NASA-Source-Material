//
// File: aimgbiekknohhdjm_norm.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:33:06 2017
//
#ifndef SHARE_aimgbiekknohhdjm_norm
#define SHARE_aimgbiekknohhdjm_norm
#include "rtwtypes.h"

extern real32_T aimgbiekknohhdjm_norm(const real32_T x[3]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
