//
// File: baaanophjmgddbie_sum.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:33:06 2017
//
#ifndef SHARE_baaanophjmgddbie_sum
#define SHARE_baaanophjmgddbie_sum
#include "rtwtypes.h"

extern real_T baaanophjmgddbie_sum(const int32_T x[16]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
