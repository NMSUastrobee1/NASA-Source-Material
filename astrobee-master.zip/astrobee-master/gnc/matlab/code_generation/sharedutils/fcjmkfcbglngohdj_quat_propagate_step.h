//
// File: fcjmkfcbglngohdj_quat_propagate_step.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1139
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Aug 22 16:52:08 2017
//
#ifndef SHARE_fcjmkfcbglngohdj_quat_propagate_step
#define SHARE_fcjmkfcbglngohdj_quat_propagate_step
#include "rtwtypes.h"

extern void fcjmkfcbglngohdj_quat_propagate_step(const real32_T quat_in[4],
  const real32_T omega[3], real32_T time_in, real_T quat_out[4]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
