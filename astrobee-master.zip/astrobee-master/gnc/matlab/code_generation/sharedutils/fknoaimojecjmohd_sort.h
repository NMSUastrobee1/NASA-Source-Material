//
// File: fknoaimojecjmohd_sort.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:14:10 2017
//
#ifndef SHARE_fknoaimojecjmohd_sort
#define SHARE_fknoaimojecjmohd_sort
#include "rtwtypes.h"

extern void fknoaimojecjmohd_sort(real32_T x[50], int32_T idx[50]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
