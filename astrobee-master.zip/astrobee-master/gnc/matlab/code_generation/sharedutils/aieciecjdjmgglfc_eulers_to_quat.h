//
// File: aieciecjdjmgglfc_eulers_to_quat.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1139
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Aug 22 16:52:08 2017
//
#ifndef SHARE_aieciecjdjmgglfc_eulers_to_quat
#define SHARE_aieciecjdjmgglfc_eulers_to_quat
#include "rtwtypes.h"

extern void aieciecjdjmgglfc_eulers_to_quat(real32_T phi, real32_T theta,
  real32_T psi, real32_T quat[4]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
