//
// File: baaiimglmglniekf_sortIdx.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:34:45 2017
//
#ifndef SHARE_baaiimglmglniekf_sortIdx
#define SHARE_baaiimglmglniekf_sortIdx
#include "rtwtypes.h"

extern void baaiimglmglniekf_sortIdx(const real_T x_data[], const int32_T
  x_sizes[2], int32_T idx_data[], int32_T idx_sizes[2]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
