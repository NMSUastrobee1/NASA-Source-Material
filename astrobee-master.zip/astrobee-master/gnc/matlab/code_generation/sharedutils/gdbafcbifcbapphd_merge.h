//
// File: gdbafcbifcbapphd_merge.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:14:10 2017
//
#ifndef SHARE_gdbafcbifcbapphd_merge
#define SHARE_gdbafcbifcbapphd_merge
#include "rtwtypes.h"

extern void gdbafcbifcbapphd_merge(int32_T idx[50], real32_T x[50], int32_T
  offset, int32_T np, int32_T nq, int32_T iwork[50], real32_T xwork[50]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
