//
// File: biekaimoppppjmoh_cat.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:14:10 2017
//
#ifndef SHARE_biekaimoppppjmoh_cat
#define SHARE_biekaimoppppjmoh_cat
#include "rtwtypes.h"

extern void biekaimoppppjmoh_cat(const int32_T varargin_1_sizes, const int32_T
  varargin_2_sizes[2], uint8_T y_data[], int32_T y_sizes[2]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
