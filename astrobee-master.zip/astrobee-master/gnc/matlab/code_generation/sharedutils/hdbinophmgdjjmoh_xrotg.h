//
// File: hdbinophmgdjjmoh_xrotg.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:33:06 2017
//
#ifndef SHARE_hdbinophmgdjjmoh_xrotg
#define SHARE_hdbinophmgdjjmoh_xrotg
#include "rtwtypes.h"

extern void hdbinophmgdjjmoh_xrotg(real32_T *a, real32_T *b, real32_T *c,
  real32_T *s);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
