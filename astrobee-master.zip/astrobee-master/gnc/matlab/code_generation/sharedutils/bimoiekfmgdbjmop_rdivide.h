//
// File: bimoiekfmgdbjmop_rdivide.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:13:05 2017
//
#ifndef SHARE_bimoiekfmgdbjmop_rdivide
#define SHARE_bimoiekfmgdbjmop_rdivide
#include "rtwtypes.h"

extern void bimoiekfmgdbjmop_rdivide(const real32_T x[2], real32_T y, real32_T
  z[2]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
