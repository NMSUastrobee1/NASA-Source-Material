//
// File: cbiemoppekfknopp_quatmult.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:33:06 2017
//
#ifndef SHARE_cbiemoppekfknopp_quatmult
#define SHARE_cbiemoppekfknopp_quatmult
#include "rtwtypes.h"

extern void cbiemoppekfknopp_quatmult(const real32_T p[4], const real32_T q[4],
  real32_T qOut[4]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
