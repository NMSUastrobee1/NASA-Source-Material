//
// File: imglknohophddjmg_eml_null_assignment.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:13:05 2017
//
#ifndef SHARE_imglknohophddjmg_eml_null_assignment
#define SHARE_imglknohophddjmg_eml_null_assignment
#include "rtwtypes.h"

extern void imglknohophddjmg_eml_null_assignment(real32_T x_data[], int32_T
  x_sizes[2], const boolean_T idx_data[], const int32_T idx_sizes);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
