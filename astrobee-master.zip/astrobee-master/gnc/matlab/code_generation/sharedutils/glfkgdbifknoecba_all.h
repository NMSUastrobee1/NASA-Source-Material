//
// File: glfkgdbifknoecba_all.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:14:10 2017
//
#ifndef SHARE_glfkgdbifknoecba_all
#define SHARE_glfkgdbifknoecba_all
#include "rtwtypes.h"

extern boolean_T glfkgdbifknoecba_all(const boolean_T x[4]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
