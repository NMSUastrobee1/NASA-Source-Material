//
// File: ecbaphdbnglnimoh_xdotc.cpp
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:33:06 2017
//
#include "rtwtypes.h"
#include "ecbaphdbnglnimoh_xdotc.h"

// Function for MATLAB Function: '<S17>/Compute Residual and H'
real32_T ecbaphdbnglnimoh_xdotc(const real32_T x[4], const real32_T y[4])
{
  return x[0] * y[2] + x[1] * y[3];
}

//
// File trailer for generated code.
//
// [EOF]
//
