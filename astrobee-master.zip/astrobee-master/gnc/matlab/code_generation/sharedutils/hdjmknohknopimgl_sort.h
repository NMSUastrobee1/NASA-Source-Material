//
// File: hdjmknohknopimgl_sort.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:34:45 2017
//
#ifndef SHARE_hdjmknohknopimgl_sort
#define SHARE_hdjmknohknopimgl_sort
#include "rtwtypes.h"

extern void hdjmknohknopimgl_sort(real32_T x[50], int32_T idx[50]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
