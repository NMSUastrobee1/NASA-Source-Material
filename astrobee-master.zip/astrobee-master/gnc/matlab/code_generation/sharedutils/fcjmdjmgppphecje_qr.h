//
// File: fcjmdjmgppphecje_qr.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:13:05 2017
//
#ifndef SHARE_fcjmdjmgppphecje_qr
#define SHARE_fcjmdjmgppphecje_qr
#include "rtwtypes.h"

extern void fcjmdjmgppphecje_qr(const real32_T A_data[], const int32_T A_sizes[2],
  real32_T Q_data[], int32_T Q_sizes[2], real32_T R_data[], int32_T R_sizes[2]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
