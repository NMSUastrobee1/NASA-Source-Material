//
// File: imohcjmoimopimoh_nullAssignment.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:33:06 2017
//
#ifndef SHARE_imohcjmoimopimoh_nullAssignment
#define SHARE_imohcjmoimopimoh_nullAssignment
#include "rtwtypes.h"

extern void imohcjmoimopimoh_nullAssignment(real32_T x_data[], int32_T x_sizes[2],
  const boolean_T idx_data[], const int32_T idx_sizes);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
