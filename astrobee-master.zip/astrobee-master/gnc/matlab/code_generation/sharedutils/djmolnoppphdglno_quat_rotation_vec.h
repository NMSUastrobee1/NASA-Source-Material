//
// File: djmolnoppphdglno_quat_rotation_vec.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1139
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Aug 22 16:52:08 2017
//
#ifndef SHARE_djmolnoppphdglno_quat_rotation_vec
#define SHARE_djmolnoppphdglno_quat_rotation_vec
#include "rtwtypes.h"

extern void djmolnoppphdglno_quat_rotation_vec(real_T vector[3], const real32_T
  Q[4], real32_T vec_out[3]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
