//
// File: fkfkbiecjecjbaie_cat.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:34:45 2017
//
#ifndef SHARE_fkfkbiecjecjbaie_cat
#define SHARE_fkfkbiecjecjbaie_cat
#include "rtwtypes.h"

extern void fkfkbiecjecjbaie_cat(const int32_T varargin_1_sizes, const int32_T
  varargin_2_sizes[2], uint8_T y_data[], int32_T y_sizes[2]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
