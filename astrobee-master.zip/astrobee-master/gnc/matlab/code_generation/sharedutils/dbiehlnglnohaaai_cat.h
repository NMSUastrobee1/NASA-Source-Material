//
// File: dbiehlnglnohaaai_cat.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:34:45 2017
//
#ifndef SHARE_dbiehlnglnohaaai_cat
#define SHARE_dbiehlnglnohaaai_cat
#include "rtwtypes.h"

extern void dbiehlnglnohaaai_cat(const uint8_T varargin_2_data[], const int32_T
  varargin_2_sizes[2], const uint8_T varargin_3_data[], const int32_T
  varargin_3_sizes[2], uint8_T y_data[], int32_T y_sizes[2]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
