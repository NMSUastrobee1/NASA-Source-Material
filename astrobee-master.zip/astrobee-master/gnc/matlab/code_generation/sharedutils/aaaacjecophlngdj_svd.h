//
// File: aaaacjecophlngdj_svd.h
//
// Code generated for Simulink model 'fam_force_allocation_module'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:13:39 2017
//
#ifndef SHARE_aaaacjecophlngdj_svd
#define SHARE_aaaacjecophlngdj_svd
#include "rtwtypes.h"

extern void aaaacjecophlngdj_svd(const real32_T A[36], real32_T U[36], real32_T
  S[9], real32_T V[9]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
