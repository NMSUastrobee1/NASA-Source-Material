//
// File: imohimopmglfaaim_sortLE.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:14:10 2017
//
#ifndef SHARE_imohimopmglfaaim_sortLE
#define SHARE_imohimopmglfaaim_sortLE
#include "rtwtypes.h"

extern boolean_T imohimopmglfaaim_sortLE(const real32_T v[17264], const int32_T
  col[2], int32_T irow1, int32_T irow2);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
