//
// File: gdjmjekfdjecpppp_svd.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:33:06 2017
//
#ifndef SHARE_gdjmjekfdjecpppp_svd
#define SHARE_gdjmjekfdjecpppp_svd
#include "rtwtypes.h"

extern void gdjmjekfdjecpppp_svd(const real32_T A[16], real32_T U[16], real32_T
  S[16], real32_T V[16]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
