//
// File: imohbaimoppphlno_cat.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1051
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Tue Nov  8 14:36:07 2016
//
#ifndef SHARE_imohbaimoppphlno_cat
#define SHARE_imohbaimoppphlno_cat
#include "rtwtypes.h"

extern void imohbaimoppphlno_cat(const real32_T varargin_1_data[], const int32_T
  varargin_1_sizes[2], const int32_T varargin_2_sizes[3], real32_T y_data[],
  int32_T y_sizes[3]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
