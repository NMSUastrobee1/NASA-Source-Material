//
// File: ekfccjmgknopmoph_svd.h
//
// Code generated for Simulink model 'fam_force_allocation_module'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:34:01 2017
//
#ifndef SHARE_ekfccjmgknopmoph_svd
#define SHARE_ekfccjmgknopmoph_svd
#include "rtwtypes.h"

extern void ekfccjmgknopmoph_svd(const real32_T A[72], real32_T U[72], real32_T
  S[36], real32_T V[36]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
