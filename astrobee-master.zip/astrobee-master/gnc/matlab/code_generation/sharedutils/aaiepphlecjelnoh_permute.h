//
// File: aaiepphlecjelnoh_permute.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Dec  4 08:33:06 2017
//
#ifndef SHARE_aaiepphlecjelnoh_permute
#define SHARE_aaiepphlecjelnoh_permute
#include "rtwtypes.h"

extern void aaiepphlecjelnoh_permute(const real32_T a_data[], const int32_T
  a_sizes[3], real32_T b_data[], int32_T b_sizes[3]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
