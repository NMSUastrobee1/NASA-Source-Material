//
// File: aaimfknongdbecjm_quat_rotation_vec.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1090
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Mon Jun 19 10:14:31 2017
//
#ifndef SHARE_aaimfknongdbecjm_quat_rotation_vec
#define SHARE_aaimfknongdbecjm_quat_rotation_vec
#include "rtwtypes.h"

extern void aaimfknongdbecjm_quat_rotation_vec(const real_T vector[3], const
  real32_T Q2[4], real32_T p_new[3]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
