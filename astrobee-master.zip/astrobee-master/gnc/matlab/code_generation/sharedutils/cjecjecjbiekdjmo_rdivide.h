//
// File: cjecjecjbiekdjmo_rdivide.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:13:05 2017
//
#ifndef SHARE_cjecjecjbiekdjmo_rdivide
#define SHARE_cjecjecjbiekdjmo_rdivide
#include "rtwtypes.h"

extern void cjecjecjbiekdjmo_rdivide(const real32_T x_data[], const int32_T
  x_sizes[2], const real32_T y_data[], real32_T z_data[], int32_T z_sizes[2]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
