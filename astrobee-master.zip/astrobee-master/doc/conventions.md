# Conventions

## Quaternions

 - Lua: x, y, z, w
 - ROS: x, y, z, w
 - Eigen: w, x, y, z
 - Matlab / Simulink: x, y, z, w
